# Thanks for posts - phpbb 3.2

## What is this repository for? ##

Thanks for posts extension updated for phpbb 3.2 with Tapatalk support (see https://github.com/Naguissa/mobiquo_thanks )


## How do I get set up? ##

 * Get the ZIP.
 * Upload to <PHPBB_ROOT>/ext/gfksx/ThanksForPosts or upload it with "Upload extensions" phpbb extension (see https://www.phpbb.com/customise/db/extension/upload/ )
 * Activate the extension


## Who do I talk to? ##

 * [Naguissa](https://github.com/Naguissa)
 * https://www.foroelectro.net (spanish phpbb forum)
